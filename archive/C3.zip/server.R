#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#
options(shiny.maxRequestSize = 30*1024^2)
packages = c('tidyverse', 'shiny', 'shinythemes','leaflet','shinyjs','raster','sp' )
sapply(packages, function(pkg) {
    #if (!require(pkg,character.only = T)) {
    #   install.packages(pkg)}
    require(pkg,character.only = T)  
})

shinyServer(function(input, output,session) {
    #credentials ####
    #It is not yet implemented
    #source('global.R')
    
    login = FALSE
    USER <- reactiveValues(login = login)
    
    observe({ 
        if (USER$login == FALSE) {
            if (!is.null(input$login)) {
                if (input$login > 0) {
                    Username <- isolate(input$userName)
                    Password <- isolate(input$passwd)
                    if(length(which(credentials$username_id==Username))==1) { 
                        pasmatch  <- credentials["passod"][which(credentials$username_id==Username),]
                        pasverify <- password_verify(pasmatch, Password)
                        if(pasverify) {
                            USER$login <- TRUE
                        } else {
                            shinyjs::toggle(id = "nomatch", anim = TRUE, time = 1, animType = "fade")
                            shinyjs::delay(3000, shinyjs::toggle(id = "nomatch", anim = TRUE, time = 1, animType = "fade"))
                        }
                    } else {
                        shinyjs::toggle(id = "nomatch", anim = TRUE, time = 1, animType = "fade")
                        shinyjs::delay(3000, shinyjs::toggle(id = "nomatch", anim = TRUE, time = 1, animType = "fade"))
                    }
                } 
            }
        }    
    })
    output$logoutbtn <- renderUI({
        req(USER$login)
        tags$li(a(icon("fa fa-sign-out"), "Logout", 
                  href="javascript:window.location.reload(true)"),
                class = "dropdown", 
                style = "background-color: #eee !important; border: 0;
                    font-weight: bold; margin:5px; padding: 10px;")
    })
    
    
    #Upload files upload ####
    rx_datapath <-reactive({
        req(input$Rx)
        Rx_file = (input$Rx) #
        if (!is.null(Rx_file)){
            # return(NULL) 
            # }else{
            tempdir =file.path('~/')#make.names(Sys.Date()))
            #rx_dir =file.path(tempdir(),'upload')
            rx_dir =file.path(tempdir)#,'upload')
            #dir.create(rx_dir, recursive = T, showWarnings = F)
            rx_filename = basename(input$Rx$datapath)
            
            rx_datapath = file.path(rx_dir,paste0(input$Rx$name))
            file.copy(input$Rx$datapath,rx_datapath,
                           overwrite = T)
            
            #Clean dir
            last_file_upload  =gsub(tools::file_ext(rx_filename[1]),'',rx_filename[1])
            all_files_in_dir = dir(rx_dir)
           
            files_2_deleted = file.path(rx_dir,
                                        all_files_in_dir[grepl(last_file_upload,all_files_in_dir)])
            #unlink(files_2_deleted)
        return(rx_datapath)}
    })
    
    
    #Print files and Check completeness of shp files ####
    output$files <- renderTable({
        req(rx_datapath())
        Rx_file = rx_datapath()# (input$Rx) #
        if (is.null(Rx_file)) {
            return(NULL) }else{
                all_files_in_dir = dir(unique(dirname(Rx_file)))
                last_file_upload  =gsub(tools::file_ext(Rx_file[1]),'',input$Rx$name[1])
                files_with_same_name_in_dir = all_files_in_dir[grepl(last_file_upload,all_files_in_dir)]
                
                #extensions = tools::file_ext(files_with_same_name_in_dir)
                min_files = c('prj', 'shp', 'shx','dbf')
                file_upload = data.frame(`File uploaded` = files_with_same_name_in_dir)
                extensions = tools::file_ext(file_upload[,1])
                file_upload$`Min Required`  =extensions %in% min_files
                
                if (any(!min_files %in% extensions)) {
                file_missing = paste0(last_file_upload, min_files[!min_files %in% extensions])
                } else{
                    file_missing = 'All set up'}
                return(file_missing) }
                #return(input$Rx$name)}
    })
    
    #read map and give option of layers
    
    # observe({
    #     
    #     # Can also set the label and select items
    #     updateSelectInput(session, "crop_variety",
    #                       #label = paste("Select input label", length(x)),
    #                       choices = my_varieties_all[[crop]],
    #                       #selected = tail(x, 1)
    #     )
    # })
    
    #plot map of location ####
    output$mymap <- renderLeaflet({
        req(rx_datapath())
        Rx_file = rx_datapath()
        if (is.null(Rx_file)){
            return(NULL)
        }else{
            all_files_in_dir = dir(unique(dirname(Rx_file)))
            last_file_upload  =gsub(tools::file_ext(Rx_file[1]),'',input$Rx$name[1])
            shp_files = all_files_in_dir[grepl(last_file_upload,all_files_in_dir)]

            #shp_file = list.files(all_files_in_dir,"shp$", full.names = T)
            shp_file = file.path(unique(dirname(Rx_file)),shp_files[grepl('.shp$',shp_files)])
            return(leaf_plot(shp_file)) #datapath
           #return( data.frame(files =shp_file))
                              #name_file= last_file_upload,
                              #shap_file =shp_file))
        }
         
        })
    #functions ####
    leaf_plot = function(Rx_file, value1=1, value2=2) {
        rx_poly = shapefile(Rx_file)
        #plot(rx_poly)
        coord_ref <-rx_poly@proj4string
        if (!grepl('longlat',coord_ref )) {
            rx_poly = spTransform(rx_poly, CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"))
        }
        offset = 0.07#if (grepl('longlat',coord_ref ))  0.07 else 100 # if geographic 0.05 grades otherwise assumed UTM in meters
        loc <- as.list(terra::ext(rx_poly))
        # value1 = 1
        # value2 = 3
        pal1 = colorBin('inferno', rx_poly[[value1]])
        pal2 = colorBin('inferno', as.numeric(rx_poly[[value2]]))
        
        leaflet(rx_poly) %>%
            setMaxBounds( lng1 = loc$xmax + offset,
                          lat1 = loc$ymax + offset,
                          lng2 = loc$xmin - offset,
                          lat2 = loc$ymin - offset ) %>% 
            addProviderTiles(providers$Esri.WorldImagery, group = "Esri Imagery",
                             options = providerTileOptions(minZoom = 10, maxZoom = 18)) %>%
            addTiles(group = "OSM (default)",
                     options = providerTileOptions(minZoom = 10, maxZoom = 18)) %>%
            #Polygon Layers
            addPolygons(data= rx_poly, weight = 1.5,
                        fillColor = ~pal1(rx_poly[[value1]]),
                        fillOpacity = 1,
                        color='darkgrey',
                        group = 'Layer 1') %>%
            addPolygons(data=rx_poly, weight = 1.5,
                        fillColor = ~pal2(as.numeric(rx_poly[[value2]])),
                        fillOpacity = 1,
                        color='darkgrey',
                        group = 'Layer 2') %>%
            #Legend Layers
            addLegend( position = "bottomleft",
                       pal=pal1, values = ~rx_poly[[value1]],group='Layer 1',
                       title = 'Layer 1',
                       opacity =1) %>%
            addLegend(position = "bottomright",
                      pal=pal2, values = ~as.numeric(rx_poly[[value2]]), group = 'Layer 2',
                      title ='Layer 2',
                      opacity =1) %>%
            #Layers Control
            addLayersControl(
                overlayGroups = c("rate_lbac","rate_gpa"),
                options = layersControlOptions(collapsed = FALSE)
            ) %>%
            addLayersControl(
                baseGroups = c("Esri Imagery","OSM (default)"),
                overlayGroups = c("Layer 1",
                                  "Layer 2"),
                options = layersControlOptions(collapsed = FALSE)
            ) %>%
            hideGroup("Layer 2") 
    }
    
    
}) #End shiny server